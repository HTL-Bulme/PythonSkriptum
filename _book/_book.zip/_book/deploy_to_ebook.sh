cp *.md ./../ebook/src -f
find ./../ebook/src -type f -exec sed -i 's/📝/![](.\/images\/ruler.svg){ width=20px }/gI' {} \;
